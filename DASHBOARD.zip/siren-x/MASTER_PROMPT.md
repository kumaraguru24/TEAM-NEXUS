# SIREN-X MASTER PROMPT — FULL-STACK AMBULANCE TRAFFIC MANAGEMENT PLATFORM

Act as a principal full-stack engineer, product designer, systems architect, and test engineer. Build a production-minded but explicitly simulation-only web application named SIREN-X: Intelligent Emergency Mobility & Traffic Coordination Platform.

## Product goal
Create a large, modular, responsive web application for a university engineering project. It should demonstrate how emergency incidents, ambulance fleet status, traffic-junction priority, and operational analytics can be coordinated in a single command interface. Do not claim it is certified or safe for real emergency dispatch. Never connect to real traffic signals; all traffic control must be simulated.

## Required stack
- Frontend: React + Vite + JavaScript (or TypeScript if the project is already TS)
- Styling: modern responsive CSS, dark command-center visual language, subtle animations, accessible focus states
- Backend: Node.js + Express REST API
- Database: PostgreSQL preferred for production; SQLite acceptable for local prototype
- Auth: hashed passwords, short-lived access tokens, role-based authorization
- API validation: schema-based validation (e.g. Zod/Joi)
- Testing: frontend component tests and backend API tests
- Code quality: clear folder structure, reusable components, environment variables, meaningful error handling, loading/empty/error states

## Visual direction
Design a premium emergency-operations dashboard:
- Deep navy backgrounds, cyan/blue highlights, green for healthy/available, amber for warnings, red for critical states
- Dense but readable data visualization; avoid excessive glow or overdecorated UI
- Sidebar navigation, top bar, breadcrumbs, global search, notifications, user menu, responsive mobile drawer
- Consistent spacing, typography, status badges, cards, tables, modal dialogs, skeleton loaders, toasts
- Accessible contrast and keyboard navigation
- Responsive at mobile, tablet and desktop sizes

## Core pages
1. Login / session management
2. Command Center overview
3. Live Fleet Tracking map
4. Incident intake and dispatch queue
5. Incident detail page
6. Ambulance fleet directory and vehicle detail
7. Traffic signal/junction registry
8. Signal simulation controls
9. Analytics and reports
10. Activity/audit log
11. User administration
12. System settings and integration status
13. Help / safety information

## Features
### Authentication and roles
- Login/logout and persistent session handling
- Roles: admin, dispatcher/operator, read-only viewer
- Backend authorization on every protected endpoint; frontend route hiding is not security
- Admin can create, disable and change roles of users
- Never seed production with public demo passwords; demo accounts must be clearly marked development-only

### Incidents
- Create incident with reference ID, category, priority, location, latitude/longitude, notes, created timestamp and status
- Validate user input on server
- Queue states: New, Dispatched, En Route, On Scene, Resolved, Cancelled
- Search/filter by status, priority, area, time and assigned ambulance
- Incident detail page with event timeline
- Dispatch an available ambulance with a confirmation dialog
- Record all important actions in append-only audit events

### Ambulances
- Registry with vehicle code, driver/crew, operational status, GPS coordinates, speed, battery/telemetry and assigned incident
- Fleet map with marker clustering if needed
- In prototype mode, use seeded and simulated coordinates
- Clearly label mock data and never present generated coordinates as actual live tracking
- Add offline/stale telemetry state

### Traffic signals — SIMULATION ONLY
- Junction registry with ID, location, current phase, timing configuration and controller status
- Simulate red/amber/green phases and a hypothetical ambulance priority window
- Check conflicts and show an operator confirmation before simulation
- Simulate return to normal after passage or timeout
- Record every simulated transition and show a prominent simulation banner
- Never send control commands to a physical controller or imply a real-world signal was changed
- Include safe fallback behavior in the simulator and test conflicting routes

### Command center
- KPI cards: fleet size, active missions, open incidents, priority simulations, resolved incidents
- Demo map, latest incidents, signal overview, recent activity and system health
- Refresh/polling with loading, error and stale-data states

### Analytics
- Incident counts by priority/status/area and date range
- Fleet availability and response-time trend using only real stored timestamps or clearly labelled synthetic demo data
- CSV export with correct escaping
- Do not invent measured performance improvements

### Admin
- User directory, create/disable user, role assignment
- Audit events and system/integration status
- Environment settings must not expose secrets to the browser

## Architecture and folder organization
Use feature-based modules, for example:
- client/src/app
- client/src/components/ui
- client/src/features/auth
- client/src/features/dashboard
- client/src/features/incidents
- client/src/features/fleet
- client/src/features/signals
- client/src/features/analytics
- client/src/features/admin
- client/src/services
- server/src/config
- server/src/middleware
- server/src/modules/auth
- server/src/modules/incidents
- server/src/modules/fleet
- server/src/modules/signals
- server/src/modules/analytics
- server/src/modules/admin
- server/src/modules/audit
- server/src/db/migrations
- server/src/db/seeds
- tests

Keep UI components, API handlers, business logic, persistence and validation separate. Avoid a giant App component. Add reusable table, badge, modal, form, metric card, alert and chart components.

## Database entities
At minimum:
- users(id, name, email, password_hash, role, is_active, created_at, updated_at)
- ambulances(id, code, driver, status, latitude, longitude, speed, battery, last_seen_at)
- incidents(id, reference, category, priority, status, location, latitude, longitude, assigned_ambulance_id, created_by, created_at, updated_at)
- signals(id, junction_code, name, area, latitude, longitude, phase, controller_mode, is_simulated)
- signal_events(id, signal_id, incident_id, event_type, old_state, new_state, created_at)
- incident_events(id, incident_id, actor_user_id, event_type, description, created_at)
- audit_logs(id, actor_user_id, action, resource_type, resource_id, metadata_json, created_at)
- system_integrations(id, name, mode, health_status, last_checked_at)

Add indexes for frequently queried status, priority, timestamp and reference fields. Use migrations and seed scripts.

## API requirements
Implement documented REST endpoints for:
- auth login/logout/me
- dashboard summary
- incident list/create/detail/update/assign/resolve
- ambulance list/detail/update status
- signal list/detail and simulation-only priority action
- analytics summary and CSV export
- admin user list/create/update/disable
- activity/audit list
- health status

Return consistent JSON and HTTP status codes. Validate all parameters and bodies. Use centralized error middleware. Add pagination and filtering for list endpoints.

## Security requirements
- Store secrets in environment variables
- Hash passwords with bcrypt/argon2
- Enforce server-side RBAC
- Apply rate limiting to authentication endpoints
- Set CORS allowlist
- Set safe HTTP headers
- Limit request body sizes
- Avoid leaking stack traces, password hashes or tokens
- Validate latitude/longitude and all IDs
- Add audit logging for privileged actions
- Explain privacy limitations and retention
- Use HTTPS in deployment
- Never expose a production admin password or secret in frontend source

## Testing and acceptance criteria
- User can sign in and sign out
- Invalid login is rejected
- Operator cannot access admin APIs
- Admin can create a user with valid input; duplicate emails fail cleanly
- User can create an incident with valid coordinates
- Invalid coordinates/priority are rejected
- Only available ambulances can be assigned
- Assignment changes incident and ambulance state atomically
- Signal priority toggles only simulation state and creates an audit event
- Dashboard counters match stored records
- Search/filter works
- CSV export escapes commas/quotes/newlines correctly
- Responsive UI works at 375px, 768px and desktop
- All pages show loading, error and empty states
- `npm run build` succeeds
- README documents setup, environment variables, test commands and limitations

## Development workflow
1. Start by summarizing architecture and file tree.
2. Implement database schema and seed data.
3. Implement auth and backend modules.
4. Implement frontend design system and shared components.
5. Implement each page incrementally.
6. Connect frontend to API.
7. Add tests and run build/test commands.
8. Fix errors based on actual terminal output; never claim a command passed unless it was run.
9. Finish with setup instructions, demo credentials for local development only, known limitations, and a prioritized roadmap.

If context or output limits are reached, do not dump all code in one response. Work in milestones and keep a `IMPLEMENTATION_STATUS.md` with completed files, next tasks, commands run, and known issues. Ask for the next milestone only when needed. Do not replace functional features with fake buttons. Label all simulated telemetry and signal control clearly.
