# SIREN-X — Ambulance Traffic Management Platform

A full-stack educational prototype for ambulance dispatch, fleet tracking, traffic-signal coordination simulation, and administration.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: SQLite (`better-sqlite3`)
- Authentication: JWT + bcryptjs
- UI: responsive dark command-center dashboard

## Requirements
- Node.js 20+ recommended
- npm

## Run locally

### 1. Backend
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
Backend runs at `http://localhost:4000`.

### 2. Frontend (new terminal)
```bash
cd client
npm install
npm run dev
```
Open the Vite URL shown in your terminal (usually `http://localhost:5173`).

## Demo login
- Admin: `admin@sirenx.local`
- Password: `SirenX!2026`
- Operator: `operator@sirenx.local`
- Password: `SirenX!2026`

Change demo credentials and JWT secret before any deployment.

## Features
- JWT login and role-aware UI
- Command center metrics and demo map
- Ambulance fleet status
- Incident creation and dispatch list
- Signal status overview and safe demo priority simulation
- Activity log
- Admin user list and system status
- SQLite persistence
- Responsive layout

## API overview
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/dashboard/summary`
- `GET /api/ambulances`
- `GET /api/incidents`
- `POST /api/incidents`
- `POST /api/incidents/:id/assign`
- `GET /api/signals`
- `POST /api/signals/:id/simulate-priority`
- `POST /api/simulation/step`
- `GET /api/activity`
- `GET /api/admin/users` (admin only)

## Safety and deployment notes
This project is a **simulation prototype**, not a certified emergency-response system. Signal actions only change demo database state; they do not connect to real traffic controllers. Real-world deployment requires authorization from relevant traffic authorities, verified signal-controller interfaces, cybersecurity review, fail-safe design, operational procedures, accessibility testing, privacy controls, and extensive field validation.

Before production:
- Use HTTPS and a managed secret store.
- Replace demo credentials and rotate JWT secrets.
- Add rate limiting, CSRF protections where applicable, audit retention, backups, monitoring and automated tests.
- Use a robust geospatial routing provider and licensed map tiles.
- Add server-side validation and stronger operational authorization.
- Never automatically change public-road signals based only on an unverified client request.
