const API = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
export function getToken(){ return localStorage.getItem('sirenx_token'); }
export function setSession(token,user){ localStorage.setItem('sirenx_token',token); localStorage.setItem('sirenx_user',JSON.stringify(user)); }
export function clearSession(){ localStorage.removeItem('sirenx_token'); localStorage.removeItem('sirenx_user'); }
export async function api(path, options={}) {
  const headers = {'Content-Type':'application/json', ...(options.headers||{})};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API}${path}`, {...options,headers});
  const data = await response.json().catch(()=>({}));
  if (response.status === 401) { clearSession(); window.dispatchEvent(new Event('sirenx:logout')); }
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
