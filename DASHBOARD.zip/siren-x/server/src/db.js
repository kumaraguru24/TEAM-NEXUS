import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';

const db = new Database('sirenx.sqlite');
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'operator',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ambulances (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  driver TEXT NOT NULL,
  status TEXT NOT NULL,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  speed INTEGER NOT NULL DEFAULT 0,
  battery INTEGER NOT NULL DEFAULT 100,
  destination TEXT
);
CREATE TABLE IF NOT EXISTS incidents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reference TEXT NOT NULL UNIQUE,
  patient_note TEXT NOT NULL,
  priority TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'New',
  location TEXT NOT NULL,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  ambulance_id INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ambulance_id) REFERENCES ambulances(id)
);
CREATE TABLE IF NOT EXISTS signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  area TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Normal',
  phase TEXT NOT NULL DEFAULT 'GREEN',
  controller_state TEXT NOT NULL DEFAULT 'SIMULATION',
  last_updated TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'info',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
if (!count) {
  const hash = bcrypt.hashSync('SirenX!2026', 10);
  const insertUser = db.prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)');
  insertUser.run('System Administrator','admin@sirenx.local',hash,'admin');
  insertUser.run('Dispatch Operator','operator@sirenx.local',hash,'operator');

  const ambulance = db.prepare(`INSERT INTO ambulances (code,driver,status,latitude,longitude,speed,battery,destination)
    VALUES (?,?,?,?,?,?,?,?)`);
  ambulance.run('AMB-07','Arun Kumar','En Route',13.0827,80.2707,42,86,'Central General Hospital');
  ambulance.run('AMB-12','Priya S','Available',13.0674,80.2376,0,94,'—');
  ambulance.run('AMB-19','Mohammed R','On Scene',13.0569,80.2425,0,73,'Anna Nagar');
  ambulance.run('AMB-23','Karthik M','Available',13.1067,80.2206,0,99,'—');

  const signal = db.prepare('INSERT INTO signals (name,area,status,phase,controller_state) VALUES (?,?,?,?,?)');
  signal.run('Mount Road Junction','Anna Salai','Priority Active','GREEN','SIMULATION');
  signal.run('Gemini Flyover Approach','Nungambakkam','Normal','GREEN','SIMULATION');
  signal.run('Teynampet Junction','Teynampet','Normal','RED','SIMULATION');
  signal.run('Royapettah High Road','Royapettah','Normal','GREEN','SIMULATION');
  signal.run('Anna Nagar Roundabout','Anna Nagar','Maintenance','AMBER','SIMULATION');

  const incident = db.prepare(`INSERT INTO incidents (reference,patient_note,priority,status,location,latitude,longitude,ambulance_id)
    VALUES (?,?,?,?,?,?,?,?)`);
  incident.run('INC-26001','Cardiac emergency','Critical','Dispatched','Teynampet, Chennai',13.0418,80.2341,1);
  incident.run('INC-26002','Road accident — assessment required','High','New','Royapettah, Chennai',13.0552,80.2644,null);
  incident.run('INC-26003','Medical assistance requested','Medium','Resolved','Nungambakkam, Chennai',13.0604,80.2433,3);

  const act = db.prepare('INSERT INTO activity (message,kind) VALUES (?,?)');
  act.run('SIREN-X demo environment initialized','success');
  act.run('AMB-07 assigned to critical incident INC-26001','warning');
  act.run('Signal simulation ready — no physical controller connected','info');
}
export default db;
