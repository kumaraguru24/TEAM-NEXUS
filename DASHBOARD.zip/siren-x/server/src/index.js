import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from './db.js';
import { authenticate, requireAdmin } from './auth.js';

const app = express();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-me';
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));

const log = (message, kind='info') => db.prepare('INSERT INTO activity(message,kind) VALUES (?,?)').run(message,kind);
const safeIncident = (row) => row && ({...row, ambulance: row.ambulance_code ? {code:row.ambulance_code,driver:row.driver} : null});

app.get('/api/health', (_req,res) => res.json({ ok:true, service:'SIREN-X API', mode:'SIMULATION' }));

app.post('/api/auth/login', (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !bcrypt.compareSync(password,user.password_hash)) return res.status(401).json({error:'Invalid email or password'});
  const token = jwt.sign({sub:user.id},JWT_SECRET,{expiresIn:'8h'});
  log(`${user.name} signed in`,'success');
  res.json({ token, user:{id:user.id,name:user.name,email:user.email,role:user.role} });
});
app.get('/api/auth/me', authenticate, (req,res) => res.json({user:req.user}));

app.get('/api/dashboard/summary', authenticate, (_req,res) => {
  const total = db.prepare('SELECT COUNT(*) n FROM ambulances').get().n;
  const active = db.prepare("SELECT COUNT(*) n FROM ambulances WHERE status IN ('En Route','On Scene')").get().n;
  const openIncidents = db.prepare("SELECT COUNT(*) n FROM incidents WHERE status NOT IN ('Resolved','Cancelled')").get().n;
  const priority = db.prepare("SELECT COUNT(*) n FROM signals WHERE status='Priority Active'").get().n;
  const resolved = db.prepare("SELECT COUNT(*) n FROM incidents WHERE status='Resolved'").get().n;
  res.json({totalAmbulances:total,activeAmbulances:active,openIncidents,prioritySignals:priority,resolvedIncidents:resolved,systemStatus:'Operational',mode:'SIMULATION'});
});

app.get('/api/ambulances', authenticate, (_req,res) => {
  res.json(db.prepare('SELECT * FROM ambulances ORDER BY id').all());
});
app.get('/api/incidents', authenticate, (_req,res) => {
  const rows = db.prepare(`SELECT i.*,a.code ambulance_code,a.driver FROM incidents i LEFT JOIN ambulances a ON a.id=i.ambulance_id ORDER BY i.id DESC`).all();
  res.json(rows.map(safeIncident));
});
app.post('/api/incidents', authenticate, (req,res) => {
  const { patient_note, priority, location, latitude, longitude } = req.body || {};
  if (!String(patient_note||'').trim() || !String(location||'').trim()) return res.status(400).json({error:'Incident description and location are required'});
  const lat = Number(latitude), lng = Number(longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) return res.status(400).json({error:'Valid latitude and longitude are required'});
  const allowed = ['Critical','High','Medium','Low'];
  if (!allowed.includes(priority)) return res.status(400).json({error:'Choose a valid priority'});
  const reference = `INC-${Date.now().toString().slice(-6)}`;
  const info = db.prepare(`INSERT INTO incidents (reference,patient_note,priority,status,location,latitude,longitude)
    VALUES (?,?,?,'New',?,?,?)`).run(reference,String(patient_note).trim().slice(0,300),priority,String(location).trim().slice(0,200),lat,lng);
  log(`New ${priority.toLowerCase()} incident ${reference} created`,'warning');
  res.status(201).json(db.prepare('SELECT * FROM incidents WHERE id=?').get(info.lastInsertRowid));
});
app.post('/api/incidents/:id/assign', authenticate, (req,res) => {
  const incident = db.prepare('SELECT * FROM incidents WHERE id=?').get(Number(req.params.id));
  const ambulance = db.prepare("SELECT * FROM ambulances WHERE id=? AND status='Available'").get(Number(req.body?.ambulanceId));
  if (!incident) return res.status(404).json({error:'Incident not found'});
  if (!ambulance) return res.status(400).json({error:'Select an available ambulance'});
  db.prepare("UPDATE incidents SET ambulance_id=?,status='Dispatched' WHERE id=?").run(ambulance.id,incident.id);
  db.prepare("UPDATE ambulances SET status='En Route',destination=? WHERE id=?").run(incident.location,ambulance.id);
  log(`${ambulance.code} dispatched to ${incident.reference}`,'warning');
  res.json({ok:true});
});

app.get('/api/signals', authenticate, (_req,res) => res.json(db.prepare('SELECT * FROM signals ORDER BY id').all()));
app.post('/api/signals/:id/simulate-priority', authenticate, (req,res) => {
  const signal = db.prepare('SELECT * FROM signals WHERE id=?').get(Number(req.params.id));
  if (!signal) return res.status(404).json({error:'Signal not found'});
  // This endpoint only changes demo state in SQLite. It does not control physical traffic signals.
  const status = signal.status === 'Priority Active' ? 'Normal' : 'Priority Active';
  const phase = status === 'Priority Active' ? 'GREEN' : 'GREEN';
  db.prepare('UPDATE signals SET status=?,phase=?,last_updated=CURRENT_TIMESTAMP WHERE id=?').run(status,phase,signal.id);
  log(`${signal.name}: demo priority ${status === 'Priority Active' ? 'enabled' : 'released'}`,'warning');
  res.json({ok:true,status,mode:'SIMULATION'});
});

app.post('/api/simulation/step', authenticate, (_req,res) => {
  const units = db.prepare("SELECT * FROM ambulances WHERE status='En Route'").all();
  const update = db.prepare('UPDATE ambulances SET latitude=?,longitude=?,speed=? WHERE id=?');
  for (const a of units) {
    const lat = a.latitude + (Math.random()-0.35)*0.0012;
    const lng = a.longitude + (Math.random()-0.35)*0.0012;
    update.run(lat,lng,Math.max(18,Math.min(55,Math.round(a.speed+(Math.random()*8-4)))),a.id);
  }
  log('Demo fleet simulation advanced one step','info');
  res.json({ok:true,updated:units.length});
});
app.get('/api/activity', authenticate, (_req,res) => {
  res.json(db.prepare('SELECT * FROM activity ORDER BY id DESC LIMIT 20').all());
});
app.get('/api/admin/users', authenticate, requireAdmin, (_req,res) => {
  res.json(db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id').all());
});
app.post('/api/admin/users', authenticate, requireAdmin, (req,res) => {
  const name=String(req.body?.name||'').trim(), email=String(req.body?.email||'').trim().toLowerCase();
  const password=String(req.body?.password||''), role=req.body?.role;
  if (!name || !email.includes('@') || password.length<10 || !['admin','operator'].includes(role)) {
    return res.status(400).json({error:'Provide name, valid email, password (10+ characters), and role'});
  }
  try {
    const info=db.prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)').run(name,email,bcrypt.hashSync(password,10),role);
    log(`Administrator created user ${email}`,'success');
    res.status(201).json({id:info.lastInsertRowid,name,email,role});
  } catch {
    res.status(409).json({error:'That email address is already registered'});
  }
});

app.use((err,_req,res,_next) => {
  console.error(err);
  res.status(500).json({error:'Unexpected server error'});
});
app.listen(PORT, () => console.log(`SIREN-X API listening on http://localhost:${PORT}`));
